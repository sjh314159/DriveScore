package com.stembotics.drivescore;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.Button;

import com.orbotix.ConvenienceRobot;
import com.orbotix.DualStackDiscoveryAgent;
import com.orbotix.async.DeviceSensorAsyncMessage;
import com.orbotix.command.ConfigureLocatorCommand;
import com.orbotix.common.DiscoveryException;
import com.orbotix.common.ResponseListener;
import com.orbotix.common.Robot;
import com.orbotix.common.RobotChangedStateListener;
import com.orbotix.common.internal.AsyncMessage;
import com.orbotix.common.internal.DeviceResponse;
import com.orbotix.common.sensor.SensorFlag;
import com.orbotix.subsystem.SensorControl;

/**
 * handles the auto drive methods
 * auto drive is placed on a non-UI thread
 * this keeps the UI thread responsive to the user
 */

public class AutoDrive extends AsyncTask<Void,Void,Void> {
    private boolean running = true;


    int speed100;           // speed value from UI slider 0 to 100
    Button btnAutoDrive;
    ConvenienceRobot mRobot;
    int shape;


    public AutoDrive(int speed100, Button btnAutoDrive, ConvenienceRobot mRobot, int shape) {
        this.speed100 = speed100;
        this.btnAutoDrive = btnAutoDrive;
        this.mRobot = mRobot;
        this.shape = shape;
        Log.d("DriveScore","AutoDrive: constructor");

    }

    @Override
    protected void onCancelled() {
        running = false;
        Log.d("DriveScore","AutoDrive: onCancelled");
    }

    @Override
    protected void onPostExecute(Void result) {
        Log.d("DriveScore","AutoDrive: onPostExecute started");
        btnAutoDrive.setText(com.stembotics.drivescore.R.string.start_auto_drive);
    }


    @Override
    protected Void doInBackground(Void... params) {
        Log.d("DriveScore","AutoDrive: doInBackground started");

        switch(shape) {
            case 0:
                driveSquare();
                break;
            case 1:
                driveTriangle();
                break;
            case 2:
                driveCircle();
                break;
            case 3:
                driveFigureEight();
                break;
        }
        return null;
    }


    private void threadSleep(int millisec) {
        try {
            Thread.sleep(millisec);
            // wait(millisec); caused app to stop
        } catch (InterruptedException e) {
            // e.printStackTrace();
        }
    }

    private void driveSquare() {
        Log.d("DriveScore","AutoDrive: driveSquare started speed100:" + speed100);
        float speed = (float) (speed100 / 100.0);
        int sideMsec = 800;
        int stopMsec = 800;
        int turnMsec = 10;
        float turn = (float) 90;
        float heading = 0;
        mRobot.drive(heading, 0);
        for(int i=0; i<9; i++) {
            // draw a side of the square, turn 90 degrees
            mRobot.drive(heading, speed);
            threadSleep(sideMsec);
            mRobot.drive(heading, 0);
            threadSleep(stopMsec);
            heading += turn;
            mRobot.drive(heading, 0);
            threadSleep(turnMsec);
            if(!running) break;
        }
    }

    private void driveTriangle() {
        Log.d("DriveScore","AutoDrive: driveTriangle started speed100" + speed100);
        float speed = (float) (speed100 / 100.0);
        int sideMsec = 800;
        int stopMsec = 800;
        int turnMsec = 10;
        float turn = (float) 120;
        float heading = 0;
        mRobot.drive(heading, 0);
        for(int i=0; i<7; i++) {
            // draw a side of the square, turn 90 degrees
            mRobot.drive(heading, speed);
            threadSleep(sideMsec);
            mRobot.drive(heading, 0);
            threadSleep(stopMsec);
            heading += turn;
            mRobot.drive(heading, 0);
            threadSleep(turnMsec);
            if(!running) break;
        }
    }

    private void driveCircle() {
        Log.d("DriveScore","AutoDrive: driveCircle started speed100" + speed100);
        int segments = 10;
        float turnAngle = (float) 360.0 / segments;
        float speed = (float) (speed100 / 200.0);
        int sideMsec = 500;
        float heading = 0;
        mRobot.drive(heading, 0);
        for(int i=0; i< 2*segments; i++) {
            // drive forward segment length
            mRobot.drive(heading, speed);
            threadSleep(sideMsec);
            // turn segment angle
            heading += turnAngle;
            if(!running) break;
        }
        // stop
        mRobot.drive(heading, 0);
    }

    private void driveFigureEight() {
        // start and stop in the middle of figure eight
        Log.d("DriveScore","AutoDrive: driveFigureEight started speed100" + speed100);
        int segments = 10;
        float turnAngle = (float) 270.0 / segments;
        float speed = (float) (speed100 / 200.0);
        int sideMsec = 500;
        float heading = 0;
        mRobot.drive(heading, 0);
        for(int n = 0; n < 2; n++) {
            // drive forware for 1 * r
            mRobot.drive(heading, speed);
            threadSleep(sideMsec);
            // draw 3/4 of circle turning right
            for (int i = 0; i < segments; i++) {
                // drive forward segment length
                mRobot.drive(heading, speed);
                threadSleep(sideMsec);
                // turn segment angle
                heading += turnAngle;
                if (!running) break;
            }
            // drive forward for 2 * r
            mRobot.drive(heading, speed);
            threadSleep(2 * sideMsec);
            // draw 3/4 of circle turning left
            for (int i = 0; i < segments; i++) {
                // drive forward segment length
                mRobot.drive(heading, speed);
                threadSleep(sideMsec);
                // turn segment angle
                heading -= turnAngle;
                if (!running) break;

            }
            // drive forward 1 * r
            mRobot.drive(heading, speed);
            threadSleep(sideMsec);
        }
        // stop
        mRobot.drive(heading, 0);
    }
}
