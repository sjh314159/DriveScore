package com.stembotics.drivescore;

import android.util.Log;

/**
 * holds the summary result features of a driving run
 * Rectangle
 * float 0 = numberTurns, 1 = averageTurnAngle, 2 = averageSpeed
 * Triangle
 * float 0 = numberTurns, 1 = averageTurnAngle, 2 = averageSpeed, 3 = varianceFromCenter
 * Other Shapes
 * float 0 = totalTime, 1 = totalDistance, 2 = averageSpeed, 3 = varianceFromCenter
 */

public class Result {

    public float result[];
    public int resultFeatureSize = 0;  // number of features depends on shape

    public boolean saved;
    public int shape;
    public int rank;  // rank based on learned weights, -1 = not yet ranked

    private float totalTimeMax = 15000;
    private float totalDistMax = 1000;
    private float numTurnsMax = 10;
    private float averageTurnAngleMax = 180;
    private float averageVelocityMax = 100;
    private float varFromCtrMax = 50;

    public Result(float data[][], int dataIndex, int shape) {
        Log.d("Drive Score","Result constructor dataIndex: " + dataIndex);
        result = new float[featureMax(shape)];
        if (shape == 0) {  // rectangle, three features
            processDataRectangle(data, dataIndex);
        } else if (shape == 1) { // triangle, four features
            processDataTriangle(data, dataIndex);
        } else {  // all other shapes, four features
            processDataOther(data, dataIndex);
        }
        saved = false;
        this.shape = shape;
        rank = -1;
    }

    // return the number of features for each shape
    public static int featureMax(int shape) {
        int result = -1;
        switch ( shape ) {
            case 0: {  // rectangle
                result = 3;
                break;
            }
            case 1: { // triangle
                result = 4;
                break;
            }
            case 2: { // circle
                result = 4;
                break;
            }
            case 3: { // figure 8
                result = 4;
                break;
            }
        }
        return result;
    }

    // after recording data this method caculates the summary features
    // float 0 = numberTurns, 1 = averageTurnAngle, 2 = averageSpeed
    private void processDataRectangle(float data[][], int dataIndex) {
        // find the scaled number of turns and scaled average turn angle
        findTurns2(data, dataIndex);

        // averageVelocity
        //scale the velocity down to a number between 0 and 1, 0 velocity = 0 scaled velocity, 45 velocity = 0.5 scaled velocity
        //anything 90 or above velocity = 1 scaled velocity (dividing by 90)
        float totalVelocity = 0;
        float averageVelocity = 0;
        float scaledAverageVelocity = 0;
        for(int i=0; i < dataIndex; i++) {
            totalVelocity += Math.sqrt(data[i][3]*data[i][3]+data[i][4]*data[i][4]);
        }
        if (dataIndex == 0) {
            averageVelocity = 0;
        } else {
            averageVelocity = totalVelocity / dataIndex;
        }
        if (averageVelocity >= averageVelocityMax)
            scaledAverageVelocity = 1;
        else
            scaledAverageVelocity = averageVelocity/averageVelocityMax;

        result[2] = scaledAverageVelocity;
    }

    // find the scaled number of turns and scaled average turn angle
    private void findTurns2(float data[][], int dataIndex) {
        int time = 0;
        int gyroZ = 6;
        float totalTurnAngle = 0;
        boolean startSearch = true;     // look for value between 10 and 100, ignore initial heading change
        boolean integrate = false; // integrate when abs(value) > 1000 until abs(value) < 100
        int numTurns = 0;
        float averageTurnAngle = 0;
        float scaledNumTurns = 0;
        float scaledAverageTurnAngle = 0;

        for(int i=1; i<dataIndex; i++) {
            if(startSearch && data[i][gyroZ] > 10 && Math.abs(data[i][gyroZ]) < 100) {
                // find first value between 10 and 100, ingnore initial heading setting
                startSearch = false;
            } else if (!startSearch && !integrate && Math.abs(data[i][gyroZ]) > 1000) {
                // after start search, find the first value above 1000, start integrating, count as a turn
                integrate = true;
                numTurns++;
                totalTurnAngle += 0.5*(data[i][gyroZ] + data[i-1][gyroZ])*(data[i][time] - data[i-1][time])/10000;
            } else if (!startSearch && integrate && Math.abs(data[i][gyroZ]) > 100) {
                // once integration started, continue to integrate until value is below 100
                totalTurnAngle += 0.5*(data[i][gyroZ] + data[i-1][gyroZ])*(data[i][time] - data[i-1][time])/10000;
            } else {
                // when not starting or not continuing to integrate, stop the integration
                // then start searching for the next integration to start
                integrate = false;
            }
            if (dataIndex == 0) {
                numTurns = 0;
                averageTurnAngle = 0;
            } else {
                averageTurnAngle = totalTurnAngle / numTurns;
            }
            scaledNumTurns = numTurns / numTurnsMax;
            scaledAverageTurnAngle = averageTurnAngle / averageTurnAngleMax;
            result[0] = scaledNumTurns;
            result[1] = scaledAverageTurnAngle;
        }
    }

    private void findTurns1(float data[][], int dataIndex) {
        //Number of Turns and Average Turn Angle
        //Scale these each to a number between 0 and 1
        //Number of turns scale
        //0 num turns = 0 scaled, 3 num turns = 0.5, 6 or above num turns = 1 (dividing by 6)
        //Average turn angle scale
        //0 avg turn = 0, 90 avg turn = 0.5, 180 avg turn = 1 (dividing by 180)
        float numTurns = 0;
        float sumTurnAngle = 0;
        float averageTurnAngle = 0;
        float scaledNumTurns = 0;
        float scaledAverageTurnAngle = 0;
        Log.d("Drive Score","Result processDataRectangle dataIndex: " + dataIndex);
        for(int i=3; i<dataIndex-3; i++) {
            if(data[i-1][6] - data[i][6]> 4000)
            {
                numTurns++;
                if ((Math.abs(data[i-2][5] - data[i+2][5])) > 180)
                    sumTurnAngle += (360-(Math.abs(data[i-2][5] - data[i+2][5])));
                else
                    sumTurnAngle += (Math.abs(data[i-2][5] - data[i+2][5]));
            }
        }

        if (numTurns > 0) {
            averageTurnAngle = sumTurnAngle / numTurns;
        } else {
            averageTurnAngle = 0;
        }
        if (numTurns >= numTurnsMax)
            scaledNumTurns = numTurnsMax;
        else
            scaledNumTurns = numTurns/numTurnsMax;

        if (averageTurnAngle > averageTurnAngleMax) {
            averageTurnAngle = averageTurnAngleMax;
        }
        scaledAverageTurnAngle = averageTurnAngle/averageTurnAngleMax;

        result[0] = scaledNumTurns;
        result[1] = scaledAverageTurnAngle;
    }


    // after recording data this method caculates the summary features
    // float 0 = numberTurns, 1 = averageTurnAngle, 2 = averageSpeed
    private void processDataTriangle(float data[][], int dataIndex) {
        // find the scaled number of turns and scaled average turn angle
        findTurns2(data, dataIndex);

        // averageVelocity
        //scale the velocity down to a number between 0 and 1, 0 velocity = 0 scaled velocity, 45 velocity = 0.5 scaled velocity
        //anything 90 or above velocity = 1 scaled velocity (dividing by 90)
        float totalVelocity = 0;
        float averageVelocity = 0;
        float scaledAverageVelocity = 0;
        for(int i=0; i < dataIndex; i++) {
            totalVelocity += Math.sqrt(data[i][3]*data[i][3]+data[i][4]*data[i][4]);
        }
        if (dataIndex == 0) {
            averageVelocity = 0;
        } else {
            averageVelocity = totalVelocity / dataIndex;
        }
        if (averageVelocity >= averageVelocityMax)
            scaledAverageVelocity = 1;
        else
            scaledAverageVelocity = averageVelocity/averageVelocityMax;

        result[2] = scaledAverageVelocity;

        // varianceFromCenter
        // find center as average X and Y value
        float totalX = 0;
        float totalY = 0;
        for(int i=0; i<dataIndex; i++) {
            totalX += data[i][1];
            totalY += data[i][2];
        }
        float centerX, centerY;
        if (dataIndex == 0) {
            centerX = totalX;
            centerY = totalY;
        } else {
            centerX = totalX / dataIndex;
            centerY = totalY / dataIndex;
        }
        // find variance from center
        // (Sum((dist from center) squared) / number) - (average dist from center squared)
        float sumDistFromCenter = 0;
        float sumDistFromCenterSquared = 0;
        for(int i=0; i<dataIndex; i++) {
            float deltaX = data[i][1] - centerX;
            float deltaY = data[i][2] - centerY;
            float distFromCenter = (float)Math.sqrt(deltaX*deltaX+deltaY*deltaY);
            sumDistFromCenter += distFromCenter;
            sumDistFromCenterSquared += distFromCenter * distFromCenter;
        }
        float averageDistFromCenter;
        if (dataIndex == 0) {
            averageDistFromCenter = sumDistFromCenter;
        } else {
            averageDistFromCenter = sumDistFromCenter / dataIndex;
        }
        if (dataIndex == 0) {
            result[3] = (float) Math.sqrt(sumDistFromCenterSquared - averageDistFromCenter * averageDistFromCenter);
        } else {
            result[3] = (float) Math.sqrt(sumDistFromCenterSquared / dataIndex - averageDistFromCenter * averageDistFromCenter);
        }
        // scale the variance from center to match other scaled values
        if (result[3] > varFromCtrMax) {
            result[3] = varFromCtrMax;
        }
        result[3] = result[3] / varFromCtrMax;
    }

    // after recording data this method caculates the summary features
    // double totalTime, totalDistance, averageVelocity, varianceFromCenter;
    private void processDataOther(float data[][], int dataIndex) {
        // last time - first time
        if (dataIndex > 0) {
            result[0] = data[dataIndex - 1][0] - data[0][0];
        } else {
            result[0] = 0;
        }
        // totalDistance
        result[1] = 0;
        for(int i=1; i<dataIndex; i++) {
            float deltaX = data[i][1] - data[i-1][1];
            float deltaY = data[i][2] - data[i-1][2];
            result[1] += (float)Math.sqrt(deltaX*deltaX+deltaY*deltaY);
        }
        // scale total distance
        if (result[1] > totalDistMax) {
            result[1] = totalDistMax;
        }
        result[1] /= totalDistMax;

        // averageVelocity
        float totalVelocity = 0;
        for(int i=0; i<dataIndex; i++) {
            totalVelocity += Math.sqrt(data[i][3]*data[i][3]+data[i][4]*data[i][4]);
        }
        // check for no data exception
        if (dataIndex == 0) {
            result[2] = 0;
        } else {
            result[2] = totalVelocity / dataIndex;
        }
        // scale average velocity
        if (result[2] > averageVelocityMax) {
            result[2] = averageVelocityMax;
        }
        result[2] /= averageVelocityMax;

        // varianceFromCenter
        // find center as average X and Y value
        float totalX = 0;
        float totalY = 0;
        for(int i=0; i<dataIndex; i++) {
            totalX += data[i][1];
            totalY += data[i][2];
        }
        float centerX, centerY;
        if (dataIndex == 0) {
            centerX = totalX;
            centerY = totalY;
        } else {
            centerX = totalX / dataIndex;
            centerY = totalY / dataIndex;
        }
        // find variance from center
        // (Sum((dist from center) squared) / number) - (average dist from center squared)
        float sumDistFromCenter = 0;
        float sumDistFromCenterSquared = 0;
        for(int i=0; i<dataIndex; i++) {
            float deltaX = data[i][1] - centerX;
            float deltaY = data[i][2] - centerY;
            float distFromCenter = (float)Math.sqrt(deltaX*deltaX+deltaY*deltaY);
            sumDistFromCenter += distFromCenter;
            sumDistFromCenterSquared += distFromCenter * distFromCenter;
        }
        float averageDistFromCenter;
        if (dataIndex == 0) {
            averageDistFromCenter = sumDistFromCenter;
        } else {
            averageDistFromCenter = sumDistFromCenter / dataIndex;
        }
        if (dataIndex == 0) {
            result[3] = (float) Math.sqrt(sumDistFromCenterSquared - averageDistFromCenter * averageDistFromCenter);
        } else {
            result[3] = (float) Math.sqrt(sumDistFromCenterSquared / dataIndex - averageDistFromCenter * averageDistFromCenter);
        }
        // scale the variance from center to match other scaled values
        if (result[3] > varFromCtrMax) {
            result[3] = varFromCtrMax;
        }
        result[3] = result[3] / varFromCtrMax;
    }

    public String getHtmlResult() {
        String s = "";
        switch (rank) {
            case -1: {
                s = "<h1>Rank: N/A</h1>";
                break;
            }
            case 0: {
                s = "<h1>Rank: Beginner (neuron 1)</h1>";
                break;
            }
            case 1: {
                s = "<h1>Rank: Intermediate (neuron 2)</h1>";
                break;
            }
            case 2: {
                s = "<h1>Rank: Expert (neuron 3)</h1>";
                break;
            }
            case 3: {
                s = "<h1>Rank: Intermediate (neuron 4)</h1>";
                break;
            }
            case 4: {
                s = "<h1>Rank: Beginner (neuron 5)</h1>";
                break;
            }
        }
        if (shape == 0) { // rectangle
            s += "<strong>Number of Turns ( Scaled ): </strong>" + Math.round(numTurnsMax*result[0]) + " ( " + result[0] + " )<br>";
            s += "<strong>Average Turn Angle ( Scaled): </strong>" + Math.round(averageTurnAngleMax*result[1]) + " ( " + result[1] + " )<br>";
            s += "<strong>Average Speed (Scaled): </strong>" + Math.round(averageVelocityMax*result[2]) + " ( " + result[2] + " )<br>";
        } else if (shape == 1) { // triangle
            s += "<strong>Number of Turns ( Scaled ): </strong>" + Math.round(numTurnsMax*result[0]) + " ( " + result[0] + " )<br>";
            s += "<strong>Average Turn Angle ( Scaled): </strong>" + Math.round(averageTurnAngleMax*result[1]) + " ( " + result[1] + " )<br>";
            s += "<strong>Average Speed (Scaled): </strong>" + Math.round(averageVelocityMax*result[2]) + " ( " + result[2] + " )<br>";
            s += "<strong>Variance From Center (Scaled): </strong>" + Math.round(1000*varFromCtrMax*result[3])/1000 + " ( " + result[3] + " )<br>";
        } else { // other shapes
            s += "<strong>Total Time ( Scaled): </strong>" + Math.round(totalTimeMax*result[0]) + " ( " + result[0] + " )<br>";
            s += "<strong>Total Distance (Scaled): </strong>" + Math.round(totalDistMax*result[1]) + " ( " + result[1] + " )<br>";
            s += "<strong>Average Speed (Scaled): </strong>" + Math.round(averageVelocityMax*result[2]) + " ( " + result[2] + " )<br>";
            s += "<strong>Variance From Center (Scaled): </strong>" + Math.round(1000*varFromCtrMax*result[3])/1000 + " ( " + result[3] + " )<br>";

        }
        return s;
    }

    public String toString() {
        String s = "";
        switch (rank) {
            case -1: {
                s = " rank: N/A\n";
                break;
            }
            case 0: {
                s = " rank: Beginner (neuron 1)\n";
                break;
            }
            case 1: {
                s = " rank: Intermediate (neuron 2)\n";
                break;
            }
            case 2: {
                s = " rank: Expert (neuron 3)\n";
                break;
            }
            case 3: {
                s = " rank: Intermediate (neuron 4) (\n";
                break;
            }
            case 4: {
                s = " rank: Beginner (neuron 5)\n";
                break;
            }
        }
        if (shape == 0) { // rectangle
            s += " scaled numberTurns: " + result[0] + "\n";
            s += " scaled averageTurnAngle: " + result[1] + "\n";
            s += " scaled averageSpeed: " + result[2] + "\n";
        } else if (shape == 1) { // triangle
            s += " scaled numberTurns: " + result[0] + "\n";
            s += " scaled averageTurnAngle: " + result[1] + "\n";
            s += " scaled averageSpeed: " + result[2] + "\n";
            s += " varianceFromCenter: " + result[3] + "\n";
        } else { // other shapes
            s += " totalTime: " + result[0] + "\n";
            s += " totalDistance: " + result[1] + "\n";
            s += " averageVelocity: " + result[2] + "\n";
            s += " varianceFromCenter: " + result[3] + "\n";
        }
        return s;
    }
}
