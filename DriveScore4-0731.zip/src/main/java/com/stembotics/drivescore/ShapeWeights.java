package com.stembotics.drivescore;

import android.text.Html;
import android.util.Log;
import android.widget.TextView;

/**
 * holds the learned weights for a shape
 * Main Methods:
 * rankResult(Result r) - calculates ranking of a result from weights
 * findWeights(ShapeWeight sr) - calculates weights from results list
 * fillShapeWeights(Shape s) - initializes weights
 */

public class  ShapeWeights {
    private TextView swTextViewOutput;
    private FileStorage fileStorage;

    int shape;
    int epochSet = 0;       // number of times results are used for learning
    int learningCount = 0;  // number of times learning has occurred
    float startLearningRate = (float)0.2;
    float learningRate = startLearningRate;

    public final static int CATEGORY_INDEX_MAX = 5;     // rank 0 =  bad, 1 = mid, 3 = good, 4 = mid, 5 = bad
    private float[][] w;

    public ShapeWeights(TextView tv, int s, FileStorage fs) {
        swTextViewOutput = tv;
        fileStorage = fs;

        shape = s;
        // size of w array set by categories and shape
        w = new float[CATEGORY_INDEX_MAX][Result.featureMax(shape)];

        // try to fill the weights from a file, otherwise initialize weights
        // if the weight file does not exist, a -1 is returned
        learningCount = fs.loadWeights(w, shape);
        if (learningCount == -1) {
            learningCount = 0;
            fillShapeWeights(shape);
        }
    }

    public String toString() {
        String result = "";
        if (shape == 0) { // rectangle
            result += "numberTurns, averageTurnAngle, averageSpeed\n";
        } else if (shape == 1) {  // triangle
            result += "numberTurns, averageTurnAngle, averageVelocity, varianceFromCenter\n";
        } else {  // other shapes
            result += "totalTime, totalDistance, averageVelocity, varianceFromCenter\n";
        }
        for (int i = 0; i < w.length; i++) {
            for (int j = 0; j < w[0].length; j++) {
                result += w[i][j] + ", ";
            }
            // remove last comma and add new line
            result = result.substring(0, result.length() - 2) + "\n";
        }
        // remove last new line
        result = result.substring(0, result.length() - 1);
        return result;
    }

    public String getCategoryHtml(int n) {
        String result = "";
        switch(n) {
            case 0: {
                result = "<strong>1 Beg: </strong>";
                break;
            }
            case 1: {
                result = "<strong>2 Int: </strong>";
                break;
            }
            case 2: {
                result = "<strong>3 Exp: </strong>";
                break;
            }
            case 3: {
                result = "<strong>4 Int: </strong>";
                break;
            }
            case 4: {
                result = "<strong>5 Beg: </strong>";
                break;
            }
        }
        return result;
    }

    public String toHTML() {
        String result = "<h3>Learned Weights</h3>";
        if (shape == 0) { // square, rectangle
            result += "<strong>Cat , Number of Turns , Average Turn Angle , Average Speed</strong><br>";
        } else if (shape == 1) {  // triangle
            result += "<strong>Cat , Number of Turns , Average Turn Angle , Average Speed , Variance From Center</strong><br>";
        } else { // circle or figure 8
            result += "<strong>Cat , Total Time , Total Distance , Average Speed , Variance From Center</strong><br>";
        }
        for (int i = 0; i < w.length; i++) {
            result += getCategoryHtml(i);
            for (int j = 0; j < w[0].length; j++) {
                result += w[i][j] + " , ";
            }
            // remove last comma and add new line
            result = result.substring(0, result.length() - 4) + "<br>";
        }
        // remove last new line
        // result = result.substring(0, result.length() - 1);
        // result += "</table>";
        return result;
    }
    // unused since every data run produces a learning cycle
    // learning rate reduces by 0.1 for each 3 learning trials
    public void findLearningRate() {
        /*
        int factor = epochSet / 3;
        learningRate = startLearningRate - (float)(0.1 * factor);
        if (learningRate < 0) {
            learningRate = 0;
        }
        */
    }

    public String getHtmlWeights() {
        String result = "";
        result = "<h2>Learning Count: " + learningCount + "</h2>";
        result += toHTML();
        return result;
    }

    // show epoch count, learning rate, and weights
    public void showEpochWeights() {
        // String s = "Epoch Set: " + epochSet + "   Learning Rate: " + learningRate + "\n";
        // String s = "Learning Count: " + learningCount + "\n";
        // s += toString();
        // swTextViewOutput.setText(s);
        String s = getHtmlWeights();
        // Log.d("DriveScore", "ShapeWeights showWeights s: " + s);
        // mTextViewOutput.setText(Html.fromHtml(getResources().getText(R.string.instructions).toString()));

        swTextViewOutput.setText(Html.fromHtml(s));
    }

    // uses weights to rank a result
    // when epoch set is zero, there has been no learning
    // ranking stored in result, which also contains the features from the trial run
    public void rankResult(Result r) {
        double d[] = new double[r.result.length];
        for(int j=0; j<d.length; j++) {
            d[j] = r.result[j];
        }
        normalizeDataVector( d );
        if(epochSet != 0) {
            double maxNeuron = 0;
            int maxOutput = 0;
            for (int j = 0; j < w.length; j++) {
                double neuron = 0;
                for (int k = 0; k < d.length; k++) {
                    // neuron += w[j][k] * d[j];  // has this been a mistake, or a change
                    neuron += w[j][k] * d[k];  // this does not seem to work, but seems wrong
                    // neuron += w[j][k] * d[j];
                }
                // check which output category is the largest
                // if it is the first, j == 0, then initialize it as largest
                if (j == 0) {
                    maxNeuron = neuron;
                    maxOutput = j;
                } else if (neuron > maxNeuron) {
                    maxNeuron = neuron;
                    maxOutput = j;
                }
            }
            r.rank = maxOutput;
        }
    }


    public void normalizeDataVector( double d[] ) {
        double sum = 0;
        for(int j=0; j<d.length; j++) {
            sum += d[j]*d[j];
        }
        sum = Math.sqrt(sum);
        for(int j=0; j<d.length; j++) {
            d[j] /= sum;
        }
    }

    public void findWeights(ShapeResults sr) {
        if (sr.resultIndex == 0) { //use training inputs only if not any test runs yet - but give output every time
                                    //change code to call findWeights every time run
                                    //need to store the weights when exiting the program so when program restarts reload those saved weights
            Log.d("DriveScore","ShapeWeights: No results to use to find weights, save some results first");
            return;
        }

        epochSet++;
        learningCount++;
        findLearningRate();

        // data array [number of results][number of features]
        //don't need to store previous arrays of data just the weights
        double[][] d = new double[sr.resultIndex][w[0].length];
        for(int i=0; i<d.length; i++) {
            for(int j=0; j<d[0].length; j++) {
                d[i][j] = sr.shapeResult[i].result[j];
            }
        }
        normalizeDataByRows( d );
        int numFeatures = d[0].length;
        int numOutputs = w.length;

        // calculate distance from sample to weights
        // determine the closest category to the sample
        // update the weights on the closest sample
        // teach this part because it is the main learning piece

        // learn from all saved results each time find weights is called, change to just learn from current result
        for(int i=0; i<d.length; i++) { // because need just current result, we don't need this whole for loop but most of what's inside - good code!
            double maxNeuron = 0;
            int maxOutput = 0;
            for (int j = 0; j < numOutputs; j++) {
                double neuron = 0;
                for (int k = 0; k < numFeatures; k++) {
                    neuron +=  w[j][k] * d[i][k];
                }
                // check which output category is the largest
                // with normalized values largest possible is 1, others smaller
                // parallel vectors will give a correlation dot product of 1
                // if it is the first, j == 0, then initialize it as smallest
                if (j == 0) {
                    maxNeuron = neuron;
                    maxOutput = j;
                } else if (neuron > maxNeuron) {
                    maxNeuron = neuron;
                    maxOutput = j;
                }
            }

            // update the weights for the maxOutput category
            for (int k = 0; k < numFeatures; k++) {
                w[maxOutput][k] = w[maxOutput][k] + (float)learningRate * (float)(d[i][k] - w[maxOutput][k]);
            }

            // so you must normalize all rows after each row update
            normalizeWeightsForRow(maxOutput);

        }

        fileStorage.saveWeights(w, shape, learningCount);
        showEpochWeights();
    }

    // normalize by row for all rows
    // sum value squared for each column
    // divide value by sqrt of sum value squared for each column
    // a[i][j] / sqrt( sum over i for each j ((a[i][j])^2 )
    public void normalizeWeightsByRows() {
        for(int i=0; i<w.length; i++) {
            normalizeWeightsForRow(i);
        }

    }

    // normalize weights by row for a single column
    public void normalizeWeightsForRow(int i) {
        float sum = 0;
        // sum values in the jth column
        for(int j = 0; j < w[0].length; j++) {
            sum += w[i][j] * w[i][j];
        }
        // check for divide by zero in normalization
        // divide values by sqrt(sum of squared values)
        if (sum == 0.0) {
            sum = 1;
        } else {
            sum = (float) Math.sqrt(sum);
        }
        for(int j = 0; j < w[0].length; j++) {
            w[i][j] /= sum;
        }
    }

    public void normalizeDataByRows( double d[][] ) {
        for(int i=0; i<d.length; i++) {
            normalizeDataForRow( d, i );
        }
    }

    public void normalizeDataForRow( double d[][], int i ) {
        double sum = 0;
        for(int j=0; j<d[0].length; j++) {
            sum += d[i][j]*d[i][j]; //changed  this from sum +=d[i][j]
        }
        // check for divide by zero in normalization
        // divide values by sqrt(sum of squared values)
        if (sum == 0.0) {
            sum = 1.0;
        } else {
            sum = Math.sqrt(sum);
        }
        for(int j=0; j<d[0].length; j++) {
            d[i][j] /= sum;
        }
    }

    public void scaleWeightsByCols() {
        for(int j = 0; j < w[0].length; j++) {
            float maxWeight = 0;
            for(int i = 0; i < w.length; i++) {
                if (w[i][j] > maxWeight) {
                    maxWeight = w[i][j];
                }
            }
            for(int i = 0; i < w.length; i++) {
                w[i][j] /= maxWeight;
            }
        }
    }

    // weights are read from a file on the device when the app starts
    // if the initial weight files are not found, these values are used
    // ==========================================================================
    // fill weights that define the ranking categories 0 =  beginner, 1 = intermediate, 3 = expert
    // SQUARE/RECTANGLE
    // initial weights would be different for different shapes, particularly variance from center
    // rank         0 = numTurns    1 = aveTurnAngle    2 = averageVelocity
    // 0 = beg      2               180                 0
    // 1 = int      3               135                 30
    // 2 = exp      4               90                  60
    // 3 = int      5               45                  30
    // 4 = beg      6               0                   0
    public void fillShapeWeights(int shape) {
        // Log.d("Drive Score","fillShapeWeights start shape: " + shape + "  w.length: " + w.length + "  w[0].length: " + w[0].length );
        String s = "";
        epochSet = 0;
        learningCount = 0;
        findLearningRate();
        switch (shape) {
            case 0: { // rectangle
                // 0 = numTurns    1 = aveTurnAngle    2 = averageVelocity
                w[0][0] = (float) 1.0;  w[0][1] = (float) 180.0; w[0][2] = (float) 10.0;
                w[1][0] = (float) 2.0;  w[1][1] = (float) 135.0; w[1][2] = (float) 20.0;
                w[2][0] = (float) 4.0;  w[2][1] = (float) 90.0;  w[2][2] = (float) 60.0;
                w[3][0] = (float) 5.0; w[3][1] = (float) 45.0;  w[3][2] = (float) 20.0;
                w[4][0] = (float) 6.0; w[4][1] = (float) 10.0;  w[4][2] = (float) 10.0;
                break;
            }
            case 1: {  // triangle
                // 0 = numTurns    1 = aveTurnAngle    2 = averageVelocity     3 = varianceFromCenter
                w[0][0] = (float) 0.5; w[0][1] = (float) 180.0; w[0][2] = (float) 5.0;  w[0][3] = (float) 0.50;
                w[1][0] = (float) 1.5; w[1][1] = (float) 160.0; w[1][2] = (float) 20.0; w[1][3] = (float) 1.25;
                w[2][0] = (float) 3.0; w[2][1] = (float) 120.0; w[2][2] = (float) 60.0; w[2][3] = (float) 2.50;
                w[3][0] = (float) 6.0; w[3][1] = (float) 60.0;  w[3][2] = (float) 20.0; w[3][3] = (float) 5.00;
                w[4][0] = (float) 9.0; w[4][1] = (float) 10.0;  w[4][2] = (float) 5.0;  w[4][3] = (float) 7.50;
                break;
            }
            case 2: {  // circle
                //  0 = totalTime   1 = totalDistance   2 = averageVelocity     3 = varianceFromCenter
                w[0][0] = (float) 1.0; w[0][1] = (float) 1.0; w[0][2] = (float) 10.0;  w[0][3] = (float) 7.50;
                w[1][0] = (float) 2.0; w[1][1] = (float) 2.0; w[1][2] = (float) 20.0; w[1][3] = (float) 5.75;
                w[2][0] = (float) 4.0; w[2][1] = (float) 4.0; w[2][2] = (float) 60.0; w[2][3] = (float) 3.00;
                w[3][0] = (float) 6.0; w[3][1] = (float) 6.0; w[3][2] = (float) 20.0; w[3][3] = (float) 5.75;
                w[4][0] = (float) 8.0; w[4][1] = (float) 8.0; w[4][2] = (float) 10.0;  w[4][3] = (float) 7.50;
                break;
            }
            case 3: {  // figure 8
                //  0 = totalTime   1 = totalDistance   2 = averageVelocity     3 = varianceFromCenter
                w[0][0] = (float) 1.0; w[0][1] = (float) 1.0; w[0][2] = (float) 10.0; w[0][3] = (float) 1.00;
                w[1][0] = (float) 2.0; w[1][1] = (float) 2.0; w[1][2] = (float) 20.0; w[1][3] = (float) 3.75;
                w[2][0] = (float) 4.0; w[2][1] = (float) 4.0; w[2][2] = (float) 60.0; w[2][3] = (float) 7.50;
                w[3][0] = (float) 6.0; w[3][1] = (float) 6.0; w[3][2] = (float) 20.0; w[3][3] = (float) 10.75;
                w[4][0] = (float) 8.0; w[4][1] = (float) 8.0; w[4][2] = (float) 10.0; w[4][3] = (float) 14.00;
                break;
            }
        }
        scaleWeightsByCols();
        normalizeWeightsByRows();
        fileStorage.saveWeights(w, shape, learningCount);
    }
    // ==========================================================================

}
