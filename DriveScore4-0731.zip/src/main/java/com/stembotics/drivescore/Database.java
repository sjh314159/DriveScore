package com.stembotics.drivescore;

import android.os.AsyncTask;
import android.widget.Button;
import android.widget.TextView;

import com.orbotix.ConvenienceRobot;

/**
 * handles all data management tasks
 * keeps track of current shape
 * stores and retrieves data results for the current shape
 * calls methods from ShapeWeights and ShapeResults using current shape
 */

public class Database {

    private TextView dbTextViewOutput;

    private int shapeMax = 4;   // number of shapes
    public int shape = 0;       // current shape 0 = square, 1 = triangle, 2 = circle, 3 = figure 8

    FileStorage fs;

    ShapeResults[] shapeResults = new ShapeResults[shapeMax];
    ShapeWeights[] shapeWeights = new ShapeWeights[shapeMax];

    AsyncTask<Void,Void,Void> autoDriveTask;

    public Database(TextView tv ) {
        dbTextViewOutput = tv;

        // create fileStorage to manage saving and loading files
        // some fileStorage functions may write to the output TextView
        fs = new FileStorage(dbTextViewOutput, shapeMax);

        for(int i=0; i<shapeMax; i++) {
            shapeResults[i] = new ShapeResults(tv, i);
            shapeWeights[i] = new ShapeWeights(tv, i, fs);
        }

    }

    public void addResults(Result r) {
        shapeResults[shape].addShapeResult(r);
    }

    public void replaceResult(Result r) {
        shapeResults[shape].replaceShapeResult(r);
    }

    public void showResults() {
        dbTextViewOutput.setText("Shape: " + shapeToString() + "\n" + shapeResults[shape].toString());
    }

    public void clearResults() {
        shapeResults[shape].clearShapeResults();
        dbTextViewOutput.setText("Shape: " + shapeToString() + "\n" + "Results cleared");
    }

    public String shapeToString() {
        String result = "";
        switch (shape) {
            case 0: {
                result = "Square";
                break;
            }
            case 1: {
                result = "Triangle";
                break;
            }
            case 2: {
                result = "Circle";
                break;
            }
            case 3: {
                result = "Figure8";
                break;
            }
        }
        return result;
    }

    public void findWeights() {
        if (shapeResults[shape].resultIndex != 0) {
            shapeWeights[shape].findWeights(shapeResults[shape]);
        }
    }

    public void fillWeights() {
        shapeWeights[shape].fillShapeWeights(shape);
    }

    public void showWeights() {
        shapeWeights[shape].showEpochWeights();
    }

    public void findRank(Result r) {
        shapeWeights[shape].rankResult(r);
    }

    public void autoDrive(int speed, Button btnAutoDrive, ConvenienceRobot mRobot) {
        autoDriveTask = new AutoDrive(speed, btnAutoDrive, mRobot, shape);
        autoDriveTask.execute();
    }

    public void autoDriveCancel() {
        autoDriveTask.cancel(true);
    }

    public String getHtmlWeights() {
        return shapeWeights[shape].getHtmlWeights();
    }

    public void saveData(float data[][], int dataIndex) {
        fs.saveData(data, dataIndex, shapeToString());
    }

}
