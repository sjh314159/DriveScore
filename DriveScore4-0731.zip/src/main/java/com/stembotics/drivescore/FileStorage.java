package com.stembotics.drivescore;

import android.os.Environment;
import android.util.Log;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * handles file storage for weights and results
 * Public Methods:
 * FileStorage() - check availability of local storage and existance of files
 * loadWeights(float[][] w) - if storage available, if file exists, load weights or return null
 * saveWeights(float[][] w) - if storage available, save weights
 * TODO: comment out log commands
 */

public class FileStorage {
    private TextView fsTextViewOutput;

    private boolean saveEnabled = false;        // can save to external storage
    private String fileFolderName = "DriveScore";
    private String weightFileName = "DriveScoreWeights";
    private String weightFileExt = "txt";
    private File weightDir;
    private File[] weightFile;

    // private String dataFileName = "DriveScoreData";
    private String dataFileName = "";
    private String dataFileExt = "csv";
    private File dataFile;
    // time stamp in seconds
    // Long tsLong = System.currentTimeMillis()/1000;
    // String ts = tsLong.toString()

    public FileStorage(TextView tv, int shapeMax) {
        fsTextViewOutput = tv;

        // check status of external storage for auto write and backup
        String extStorageState = Environment.getExternalStorageState();
        saveEnabled = (Environment.MEDIA_MOUNTED.equals(extStorageState)
                && !Environment.MEDIA_MOUNTED_READ_ONLY.equals(extStorageState));
        if (!saveEnabled) {
            Log.e("DriveScore","NOTICE FileStorage: External storage unavailable, data will not be saved");
        }

        if (saveEnabled) {
            String folder = Environment.getExternalStorageDirectory() + "/" + fileFolderName;
            // initialize weight file objects
            weightDir = new File(folder);

            weightFile = new File[shapeMax];
            for(int i=0; i<weightFile.length; i++) {
                String filename = weightFileName + i + "." + weightFileExt;
                weightFile[i] = new File(folder, filename);
            }
        }
    }

    int loadWeights(float[][] w, int shape) {
        int learningCount = -1;
        if (saveEnabled) {
            if(weightFile[shape].exists()) {
                try {
                    FileInputStream fis = new FileInputStream(weightFile[shape]);
                    DataInputStream in = new DataInputStream(fis);
                    BufferedReader br = new BufferedReader(new InputStreamReader(in));
                    String strLine = "";
                    strLine = br.readLine();
                    learningCount = Integer.parseInt(strLine);
                    Log.d("DriveScore","loadWeights learningCount: " + learningCount);
                    strLine = br.readLine();
                    Scanner s = new Scanner(strLine).useDelimiter(" ");
                    // file has the number of rows and number of columns for the data
                    int numRows = s.nextInt();
                    int numCols = s.nextInt();
                    Log.d("DriveScore","loadWeights numRows, numCols: " + numRows + ", " + numCols);
                    if ( (numRows == w.length) && ( numCols == w[0].length ) ) {
                        for (int i = 0; i < w.length; i++) {
                            strLine = br.readLine();
                            s = new Scanner(strLine).useDelimiter(" ");
                            for (int j = 0; j < w[0].length; j++) {
                                w[i][j] = s.nextFloat();
                                Log.d("DriveScore","loadWeights: w " + i + "," + j + "=" + w[i][j]);
                            }
                        }
                        Log.d("DriveScore","loadWeights: input file " + weightFileName + shape + "." + weightFileExt + " loaded");
                    } else {
                        Log.e("DriveScore","loadWeights: input file incorrect number of rows or columns");
                    }
                    in.close();
                } catch (IOException e) {
                    Log.e("DriveScore",e.getMessage());
                }

            } else {
                Log.e("DriveScore","loadWeights: load weights file shape " + shape + " NOT found" );
            }
        }
        Log.d("DriveScore","loadWeights return learningCount: " + learningCount);
        return learningCount;
    }


    void saveWeights(float[][] w, int shape, int learningCount) {
        if (saveEnabled) {
            if(!weightDir.exists()) {
                Log.d("DriveScore", "saveWeights: create directory");
                weightDir.mkdir();
            }
            FileWriter fw;
            PrintWriter pw;
            try {
                Log.d("DriveScore", "saveWeights: save weights shape " + shape);
                fw = new FileWriter(weightFile[shape]);
                pw = new PrintWriter(fw);

                // save number of rows and columns
                // then save the weight data
                pw.println(learningCount);
                pw.println(w.length + " " + w[0].length);
                for (int i = 0; i < w.length; i++) {
                    for (int j = 0; j < w[0].length; j++) {
                        pw.print(w[i][j]);
                        if (j < w[0].length - 1) {
                            pw.print(" ");
                        } else {
                            pw.println("");
                        }
                    }
                }

                pw.flush();
                pw.close();
                Log.d("DriveScore", "saveWeights: file closed");
            } catch (IOException e) {
                Log.e("DriveScore", e.getMessage());
            }
        } else {
            Log.e("DriveScore", "saveWeights: External storage unavailable, data will not be saved");
        }
    }

    public void saveData(float data[][], int dataIndex, String shapeName) {
        if (saveEnabled) {
            if(!weightDir.exists()) {
                Log.d("DriveScore", "saveWeights: create directory");
                weightDir.mkdir();
            }
            FileWriter fw;
            PrintWriter pw;
            try {
                Log.d("DriveScore", "saveData: save data dataIndex " + dataIndex);
                Long tsLong = System.currentTimeMillis()/1000;
                String ts = tsLong.toString();
                String filename = dataFileName + shapeName + ts + "." + dataFileExt;
                String folder = Environment.getExternalStorageDirectory() + "/" + fileFolderName;
                dataFile = new File(folder, filename);

                fw = new FileWriter(dataFile);
                pw = new PrintWriter(fw);
                // save the data headings
                /*
                data[dataIndex][0] = currentTimeMillis - startTimeMillis;
                    data[dataIndex][1] = posX;
                    data[dataIndex][2] = posY;
                    data[dataIndex][3] = velX;
                    data[dataIndex][4] = velY;
                    data[dataIndex][5] = gyroYaw;
                    data[dataIndex][6] = gyroZ;
                */
                pw.print("\"time\",");
                pw.print("\"posX\",");
                pw.print("\"posY\",");
                pw.print("\"velX\",");
                pw.print("\"velY\",");
                pw.print("\"gyroYaw\",");
                pw.print("\"gyroZ\",");
                pw.println("");
                // save the data
                for (int i = 0; i < dataIndex; i++) {
                    for (int j = 0; j < data[0].length; j++) {
                        pw.print(data[i][j]);
                        if (j < data[0].length - 1) {
                            pw.print(",");
                        } else {
                            pw.println("");
                        }
                    }
                }

                pw.flush();
                pw.close();
                Log.d("DriveScore", "saveData: file closed");
            } catch (IOException e) {
                Log.e("DriveScore", e.getMessage());
            }
        } else {
            Log.e("DriveScore", "saveData: External storage unavailable, data will not be saved");
        }
    }

}
