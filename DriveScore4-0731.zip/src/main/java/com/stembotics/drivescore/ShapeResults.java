package com.stembotics.drivescore;

import android.content.Context;
import android.os.Environment;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * holds the summary features of a driving run
 * the app functions were changed and this class is really not used in the current version
 * TODO: remove this class
 */

public class ShapeResults {

    private TextView srTextViewOutput;

    public int resultIndex = 0;
    public int resultIndexMax = 50;
    public Result[] shapeResult;

    public ShapeResults(TextView tv, int shape) {
        srTextViewOutput = tv;
        clearShapeResults();
    }

    public void clearShapeResults() {
        shapeResult = new Result[resultIndexMax];
        resultIndex = 0;
    }

    public void addShapeResult(Result r) {
        if (resultIndex > resultIndexMax) {
            srTextViewOutput.setText("ERROR: Maximum result storage for shape exceeded, result not saved");
        } else if (r.saved) {
            srTextViewOutput.setText("NOTICE: Result already saved, result not saved again");
        } else {
            r.saved = true;
            shapeResult[resultIndex] = r;
            String s = "SAVED:\n" + r.toString();
            srTextViewOutput.setText(s);
            resultIndex++;
        }
    }

    public void replaceShapeResult(Result r) {
        // replaces the first shapeResult with the current result
        // originally a number of results were stored in shapeResult
        // then the collection of results were used for learning
        // now only the current result is stored
        // learning is done on each result
        resultIndex = 0;
        shapeResult[resultIndex] = r;
        resultIndex = 1;
    }

    public String toString() {
        String s = "";
        for(int i=0; i<resultIndex; i++) {
            s += "i: " + i + " ";
            s += shapeResult[i].toString();
            s += "\n";
        }
        return s;
    }


}
