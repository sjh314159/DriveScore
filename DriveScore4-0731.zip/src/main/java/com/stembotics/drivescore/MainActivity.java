package com.stembotics.drivescore;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

import android.os.Environment;

import com.orbotix.ConvenienceRobot;
import com.orbotix.DualStackDiscoveryAgent;
import com.orbotix.async.DeviceSensorAsyncMessage;
import com.orbotix.command.ConfigureLocatorCommand;
import com.orbotix.common.DiscoveryException;
import com.orbotix.common.ResponseListener;
import com.orbotix.common.Robot;
import com.orbotix.common.RobotChangedStateListener;
import com.orbotix.common.internal.AsyncMessage;
import com.orbotix.common.internal.DeviceResponse;
import com.orbotix.common.sensor.SensorFlag;
import com.orbotix.subsystem.SensorControl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import android.widget.Switch;
import android.widget.TextView;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;

import android.widget.RadioButton;

import io.github.controlwear.virtual.joystick.android.JoystickView;
import android.view.ViewGroup.LayoutParams;
import android.widget.RelativeLayout;

import android.content.res.TypedArray;


/**
 * Locator sample
 *
 * Keeps track of the robot's position by recording direction and speed.
 * This sample demonstrates how to use the Locator and Velocity sensors.
 *
 * For more explanation on driving, see the Button Drive sample
 *
 */
public class MainActivity extends Activity implements View.OnClickListener, RobotChangedStateListener, ResponseListener {

    private static final int REQUEST_CODE_LOCATION_PERMISSION = 42;
    private static final float ROBOT_VELOCITY = 0.4f;

    private ConvenienceRobot mRobot = null;

    // save results switch
    private boolean mCheckSaveData = false;

    // start and stop button status
    private boolean mRecording = false;
    private boolean mSetHeading = false;
    private boolean mAutoDrive = false;

    Database db;

    int dataIndex = 0;          // number of data points in a recorded run
    int dataIndexMax = 500;     // maximum number of data points in a recorded run
    int dataSensorsMax = 7;     // number of sensors recorded from sphero
    private float data[][];     // data array 0 = time, 1 = pX, 2 = pY, 3 = vX, 4 = vY, 5 = attitudeYaw, 6 = gyroZ
    private Result result;      // current result from data

    int currentAngle = 0;       // current angle for joystick, helps with joystick release
    int speed = 50;             // speed setting from seek bar

    // robot connection control
    private Switch mSwitchConnect;
    private TextView mTextViewStatus;
    private Switch mSwitchSaveData;

    // robot initialization and recording
    private Button mBtnSetHeading;
    private Button mBtnAutoDrive;
    private Button mBtnStartRecording;

    // speed seek bars
    private TextView textViewSpeedLeft;
    private SeekBar seekBarSpeedLeft;
    private TextView textViewSpeedRight;
    private SeekBar seekBarSpeedRight;

    // joystick left and right
    JoystickView joystickviewleft;
    JoystickView joystickviewright;

    // instructions and activity control
    private Button mBtnInstructions;
    private Button mBtnFlipJoystick;
    private Button mBtnClearWeights;

    // shape selection
    private Button mRadioTriangle;
    private Button mRadioSquare;
    private Button mRadioCircle;
    private Button mRadioEight;

    // output
    private TextView mTextViewOutput;

    long startTimeMillis, currentTimeMillis, stopTimeMillis;

    double totalTime, totalDistance, averageVelocity, varianceFromCenter;
    float startX, startY;
    boolean zeroXY = true;

    boolean showJoystickLeft = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView( com.stembotics.drivescore.R.layout.activity_main );

        /*
            Associate a listener for robot state changes with the DualStackDiscoveryAgent.
            DualStackDiscoveryAgent checks for both Bluetooth Classic and Bluetooth LE.
            DiscoveryAgentClassic checks only for Bluetooth Classic robots.
            DiscoveryAgentLE checks only for Bluetooth LE robots.
       */
        DualStackDiscoveryAgent.getInstance().addRobotStateListener( this );

        initViews();

        Context context = getApplicationContext();

        if( Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ) {
            int hasLocationPermission = checkSelfPermission( Manifest.permission.ACCESS_COARSE_LOCATION );
            if( hasLocationPermission != PackageManager.PERMISSION_GRANTED ) {
                Log.e( "DriveScore", "Location permission has not already been granted" );
                List<String> permissions = new ArrayList<String>();
                permissions.add( Manifest.permission.ACCESS_COARSE_LOCATION );
                requestPermissions(permissions.toArray(new String[permissions.size()] ), REQUEST_CODE_LOCATION_PERMISSION );
            } else {
                Log.d( "DriveScore", "Location permission already granted" );
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                int hasWriteExtStoragePermission = checkSelfPermission( Manifest.permission.WRITE_EXTERNAL_STORAGE );
                if( hasWriteExtStoragePermission != PackageManager.PERMISSION_GRANTED ) {
                    Log.e( "DriveScore", "Write external storage permission has not already granted" );
                    requestPermissions(new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                } else {
                    Log.d( "DriveScore", "Write external storage permission already granted" );
                }
            }

        }

        // create database to manage store and manage data functions
        // some database functions may write to the output TextView
        db = new Database(mTextViewOutput);
        db.showWeights();
    }

    private void initViews() {

        mSwitchConnect = (Switch) findViewById(com.stembotics.drivescore.R.id.switchConnect);
        mTextViewStatus = (TextView) findViewById( com.stembotics.drivescore.R.id.textViewStatus );
        mSwitchSaveData = (Switch) findViewById(com.stembotics.drivescore.R.id.switchSaveData);

        mBtnSetHeading = (Button) findViewById( com.stembotics.drivescore.R.id.btn_setheading );
        mBtnAutoDrive = (Button) findViewById( com.stembotics.drivescore.R.id.btn_autodrive );
        mBtnStartRecording = (Button) findViewById( com.stembotics.drivescore.R.id.btn_startrecording );

        mRadioTriangle = (RadioButton) findViewById( com.stembotics.drivescore.R.id.radiotriangle );
        mRadioSquare = (RadioButton) findViewById( com.stembotics.drivescore.R.id.radiosquare );
        mRadioCircle = (RadioButton) findViewById( com.stembotics.drivescore.R.id.radiocircle );
        mRadioEight = (RadioButton) findViewById( com.stembotics.drivescore.R.id.radioeight );

        textViewSpeedLeft = (TextView) findViewById( com.stembotics.drivescore.R.id.textviewspeedleft );
        seekBarSpeedLeft = (SeekBar) findViewById( com.stembotics.drivescore.R.id.seekbarspeedleft );
        textViewSpeedRight = (TextView) findViewById( com.stembotics.drivescore.R.id.textviewspeedright );
        seekBarSpeedRight = (SeekBar) findViewById( com.stembotics.drivescore.R.id.seekbarspeedright );

        mBtnInstructions = (Button) findViewById( com.stembotics.drivescore.R.id.btn_instructions );
        mBtnFlipJoystick = (Button) findViewById( com.stembotics.drivescore.R.id.btn_flipjoystick );
        mBtnClearWeights = (Button) findViewById( com.stembotics.drivescore.R.id.btn_clearweights );

        mTextViewOutput = (TextView) findViewById( com.stembotics.drivescore.R.id.outputText );

        mBtnSetHeading.setOnClickListener( this );
        mBtnAutoDrive.setOnClickListener( this );
        mBtnStartRecording.setOnClickListener( this );

        mBtnInstructions.setOnClickListener( this );
        mBtnFlipJoystick.setOnClickListener( this );
        mBtnClearWeights.setOnClickListener( this );

        seekBarSpeedLeft.setMax(100);
        seekBarSpeedLeft.setProgress(speed);
        seekBarSpeedLeft.setOnSeekBarChangeListener( new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                speed = seekBar.getProgress();
                Log.d("DriveScore", "main left seek bar: speed set to " + speed);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

        });

        seekBarSpeedRight.setMax(100);
        seekBarSpeedRight.setProgress(speed);
        seekBarSpeedRight.setOnSeekBarChangeListener( new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                speed = seekBar.getProgress();
                Log.d("DriveScore", "main right seek bar: speed set to " + speed);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

        });

        joystickviewleft = (JoystickView) findViewById(com.stembotics.drivescore.R.id.joystickViewLeft);
        joystickviewleft.setOnMoveListener(new JoystickView.OnMoveListener() {
            @Override
            public void onMove(int angle, int strength) {
                joystickOnMoveHandler(angle, strength);
            }
        });

        joystickviewright = (JoystickView) findViewById(com.stembotics.drivescore.R.id.joystickViewRight);
        joystickviewright.setOnMoveListener(new JoystickView.OnMoveListener() {
            @Override
            public void onMove(int angle, int strength) {
                joystickOnMoveHandler(angle, strength);
            }
        });

        joystickviewright.setVisibility(View.INVISIBLE);
        textViewSpeedRight.setVisibility(View.INVISIBLE);
        seekBarSpeedRight.setVisibility(View.INVISIBLE);
        joystickviewright.setVisibility(View.INVISIBLE);

        mSwitchSaveData.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // The switch is enabled
                    mCheckSaveData = true;
                } else {
                    // The switch is disabled
                    mCheckSaveData = false;
                }
            }
        });

        mSwitchConnect.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // The switch is enabled
                    mTextViewStatus.setText("Robot Discovery ... Please wait");
                    startDiscovery();
                } else {
                    // The switch is disabled
                    mTextViewStatus.setText("Robot Disconnected");
                    stopRobot();
                }
            }
        });

    }

    public void joystickOnMoveHandler(int angle, int strength) {
        // when strength is zero (joystick released) angle = 0 degrees
        // otherwise angle is reset so up is 0 degrees and 90 is to the right
        if (strength > 10) {
            currentAngle = 360 - (angle + 270) % 360;
        }

        if (mRobot != null) {
            if (mSetHeading) {
                if (strength > 80) {
                    mRobot.drive(angle, 0);
                }
            } else {
                if (strength < 10) {
                    strength = 0;
                }
                mRobot.drive(currentAngle, (float) ((strength / 100.0)*(speed / 100.0)));
            }
        }
                /*
                if (strength > 10 ) {
                    angle = 360 - (angle + 270) % 360;
                }
                if (mRobot != null) {
                    if (mSetHeading) {
                        if (strength > 80) {
                            mRobot.drive(angle, 0);
                        }
                    } else {
                        //if (strength > 10)
                        mRobot.drive(angle, (float) (strength / 100.0));
                    }
                }
                */
    }

    // set the current shape
    // shape: 0 = square, 1 = triangle, 2 = circle, 3 = figure 8
    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case com.stembotics.drivescore.R.id.radiosquare:
                if (checked) {
                    // square
                    db.shape = 0;
                    db.showWeights();
                }
                break;
            case com.stembotics.drivescore.R.id.radiotriangle:
                if (checked) {
                    // triangle
                    db.shape = 1;
                    db.showWeights();
                }
                break;
            case com.stembotics.drivescore.R.id.radiocircle:
                if (checked) {
                    // circle
                    db.shape = 2;
                    db.showWeights();
                }
                break;
            case com.stembotics.drivescore.R.id.radioeight:
                if (checked) {
                    // figure 8
                    db.shape = 3;
                    db.showWeights();
                }
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch ( requestCode ) {
            case REQUEST_CODE_LOCATION_PERMISSION: {
                for( int i = 0; i < permissions.length; i++ ) {
                    if( grantResults[i] == PackageManager.PERMISSION_GRANTED ) {
                        startDiscovery();
                        Log.d( "Permissions", "Permission Granted: " + permissions[i] );
                    } else if( grantResults[i] == PackageManager.PERMISSION_DENIED ) {
                        Log.d( "Permissions", "Permission Denied: " + permissions[i] );
                    }
                }
            }
            break;
            default: {
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();

        if( Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                || checkSelfPermission( Manifest.permission.ACCESS_COARSE_LOCATION ) == PackageManager.PERMISSION_GRANTED ) {
            if ( mSwitchConnect.isChecked() ) {
                startDiscovery();
            }
        }
    }

    private void startDiscovery() {
        //If the DiscoveryAgent is not already looking for robots, start discovery.
        if( !DualStackDiscoveryAgent.getInstance().isDiscovering() ) {
            try {
                DualStackDiscoveryAgent.getInstance().startDiscovery(this);
            } catch( DiscoveryException | NullPointerException e ) {
                Log.e("DriveScore","MainActivity: DiscoveryException: " + e.getMessage());
            }
        }
    }

    private void stopRobot() {
        //If the DiscoveryAgent is in discovery mode, stop it.
        if( DualStackDiscoveryAgent.getInstance().isDiscovering() ) {
            DualStackDiscoveryAgent.getInstance().stopDiscovery();
        }

        //If a robot is connected to the device, disconnect it
        if( mRobot != null ) {
            mRobot.setBackLedBrightness(0);
            mRobot.disconnect();
            mRobot = null;
        }
    }

    @Override
    protected void onStop() {
        stopRobot();

        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        DualStackDiscoveryAgent.getInstance().addRobotStateListener(null);
    }

    @Override
    public void onClick(View v) {

        // buttons that are active when robot is disconnected
        if (v.getId() == com.stembotics.drivescore.R.id.btn_instructions) {
            mTextViewOutput.setText(Html.fromHtml(getResources().getText(R.string.instructions).toString()));
        } else if (v.getId() == com.stembotics.drivescore.R.id.btn_flipjoystick) {
            if (showJoystickLeft) {
                showJoystickLeft = false;
                textViewSpeedLeft.setVisibility(View.INVISIBLE);
                seekBarSpeedLeft.setVisibility(View.INVISIBLE);
                joystickviewleft.setVisibility(View.INVISIBLE);

                seekBarSpeedRight.setProgress(speed);
                textViewSpeedRight.setVisibility(View.VISIBLE);
                seekBarSpeedRight.setVisibility(View.VISIBLE);
                joystickviewright.setVisibility(View.VISIBLE);

            } else {
                showJoystickLeft = true;
                seekBarSpeedLeft.setProgress(speed);
                textViewSpeedLeft.setVisibility(View.VISIBLE);
                seekBarSpeedLeft.setVisibility(View.VISIBLE);
                joystickviewleft.setVisibility(View.VISIBLE);

                textViewSpeedRight.setVisibility(View.INVISIBLE);
                seekBarSpeedRight.setVisibility(View.INVISIBLE);
                joystickviewright.setVisibility(View.INVISIBLE);

            }
        } else if (v.getId() == com.stembotics.drivescore.R.id.btn_clearweights) {
            db.fillWeights();
            db.showWeights();
        }

        // return if robot is disconnected
        if (mRobot == null) {
            return;
        }

        // active buttons when robot is connected
        if (v.getId() == com.stembotics.drivescore.R.id.btn_setheading) {
            if (mSetHeading) {
                // stop set heading
                mBtnSetHeading.setText("Start Set Heading");
                mSetHeading = false;
                mRobot.setLed(0, 1, 0);
                mRobot.setBackLedBrightness(0);
                mRobot.setZeroHeading();
            } else {
                // start set heading
                mBtnSetHeading.setText("Stop Set Heading");
                mSetHeading = true;
                mRobot.setBackLedBrightness(1);
                mRobot.setLed(1, 0, 0);
            }
        } else if (v.getId() == com.stembotics.drivescore.R.id.btn_autodrive) {
            // if (mAutoDrive) not working with AsyncTask
            // button controls AsyncTask which cannot access the state flag mAutoDrive
            // so the state of the button (start or stop) is flagged by the button text
            if (mBtnAutoDrive.getText().toString().equalsIgnoreCase(getResources().getString(com.stembotics.drivescore.R.string.stop_auto_drive))) {
                // stop autodrive
                mBtnAutoDrive.setText(com.stembotics.drivescore.R.string.start_auto_drive);
            mAutoDrive = false;
            db.autoDriveCancel();
            } else {
                // start auto drive
                mBtnAutoDrive.setText(com.stembotics.drivescore.R.string.stop_auto_drive);
                mAutoDrive = true;
                db.autoDrive(speed, mBtnAutoDrive, mRobot);
            }
        } else if ( v.getId() == com.stembotics.drivescore.R.id.btn_startrecording ) {
            if (mRecording) {
                // stop recording
                mBtnStartRecording.setText(com.stembotics.drivescore.R.string.start_recording);
                mRecording = false;
                stopTimeMillis = System.currentTimeMillis();
                // processData();
                // create a result object depending on the shape used
                // if save data switch is check, save the raw data to a file
                Log.d("Drive Score","MainActivity onClick save data dataIndex: " + dataIndex);
                if (mCheckSaveData) {
                    db.saveData(data, dataIndex);
                }
                Log.d("Drive Score","MainActivity onClick new Result dataIndex: " + dataIndex);
                result = new Result(data, dataIndex, db.shape);
                db.replaceResult(result);   // only saves one result into the result array
                db.findWeights();           // finds the weights with one result in array
                db.findRank(result);        // finds rank of the last result, store in result
                // db.showWeights();           // shows the current weights
                // String s = result.toString() + "\n\n" + mTextViewOutput.getText().toString() + "\n";
                String s = result.getHtmlResult() + db.getHtmlWeights();
                // String s = "<h3>" +  + "</h3>" + mTextViewOutput.getText().toString();
                mTextViewOutput.setText(Html.fromHtml(s));
                zeroXY = true;
            } else {
                // start recording
                mBtnStartRecording.setText(com.stembotics.drivescore.R.string.stop_recording);
                mRecording = true;
                dataIndex = 0;
                data = new float[dataIndexMax][dataSensorsMax];
                mTextViewOutput.setText("");
                startTimeMillis = System.currentTimeMillis();
            }
        }
    }

    @Override
    public void handleResponse(DeviceResponse response, Robot robot) {
    }

    @Override
    public void handleStringResponse(String stringResponse, Robot robot) {
    }

    @Override
    public void handleAsyncMessage(AsyncMessage asyncMessage, Robot robot) {
        if( asyncMessage instanceof DeviceSensorAsyncMessage ) {
            if ( ( (DeviceSensorAsyncMessage) asyncMessage ).getAsyncData() == null) {
                Log.e("DriveScore", "MainActivity: ArrayList null");
                // mTextViewOutput.setText("SPHERO needs to be reset, place in charging station");
                mSwitchConnect.setChecked(false);
                mTextViewStatus.setText("ERROR: Reset Sphero and try again");
            } else if ( ( (DeviceSensorAsyncMessage) asyncMessage ).getAsyncData().isEmpty()) {
                mTextViewOutput.setText("Empty Message");
            } else {
                float positionX = ((DeviceSensorAsyncMessage) asyncMessage).getAsyncData().get(0).getLocatorData().getPositionX();
                float positionY = ((DeviceSensorAsyncMessage) asyncMessage).getAsyncData().get(0).getLocatorData().getPositionY();
                float velocityX = ((DeviceSensorAsyncMessage) asyncMessage).getAsyncData().get(0).getLocatorData().getVelocity().x;
                float velocityY = ((DeviceSensorAsyncMessage) asyncMessage).getAsyncData().get(0).getLocatorData().getVelocity().y;
                //changed this from pitch to yaw - is there a reason it was pitch?
                float gyroYaw = ((DeviceSensorAsyncMessage) asyncMessage).getAsyncData().get(0).getAttitudeData().yaw;
                float gyroZ =  ((DeviceSensorAsyncMessage) asyncMessage).getAsyncData().get(0).getGyroData().getRotationRateFiltered().z;

                if(zeroXY) {
                    startX = positionX;
                    startY = positionY;
                    zeroXY = false;
                }

                positionX = positionX - startX;
                positionY = positionY - startY;

                // record data when recording flag is set
                if (mRecording && (dataIndex < dataIndexMax)) {
                    currentTimeMillis = System.currentTimeMillis();
                    data[dataIndex][0] = currentTimeMillis - startTimeMillis;
                    data[dataIndex][1] = positionX;
                    data[dataIndex][2] = positionY;
                    data[dataIndex][3] = velocityX;
                    data[dataIndex][4] = velocityY;
                    data[dataIndex][5] = gyroYaw;
                    data[dataIndex][6] = gyroZ;

                    String out = "i: " + dataIndex;
                    out += " t: " + data[dataIndex][0];
                    out += " pX: " + data[dataIndex][1];
                    out += " pY: " + data[dataIndex][2];
                    out += " vX: " + data[dataIndex][3];
                    out += " vY: " + data[dataIndex][4];
                    out += " gYaw: " + data[dataIndex][5];
                    out += " gZ: " + data[dataIndex][6];
                    out += "\n";
                    out += mTextViewOutput.getText();
                    mTextViewOutput.setText(out);

                    dataIndex++;
                }
            }
        }
    }

    @Override
    public void handleRobotChangedState(Robot robot, RobotChangedStateNotificationType type) {
        switch (type) {
            case Online: {

                //Sensor flags can be bitwise ORed together to enable multiple sensors
                long sensorFlag = SensorFlag.VELOCITY.longValue()
                        | SensorFlag.LOCATOR.longValue()
                        | SensorFlag.GYRO_NORMALIZED.longValue()
                        | SensorFlag.ATTITUDE.longValue();

                //Save the robot as a ConvenienceRobot for additional utility methods
                mRobot = new ConvenienceRobot(robot);

                //Enable sensors based on earlier defined flags, and set the streaming rate.
                //This example streams data from the connected robot 10 times a second.
                mRobot.enableSensors( sensorFlag, SensorControl.StreamingRate.STREAMING_RATE10 );
                mRobot.addResponseListener( this );

                mTextViewStatus.setText("Robot Connected");
                mRobot.setBackLedBrightness(0);
                mRobot.setLed(0,1,0);

                break;
            }
        }
    }


}
